from distutils.core import setup

setup(
        name         = 'mz_nester',
        version      = '1.1.0',
        py_modules   = ['mz_nester'],
        author       = 'moky zhang',
        author_email = 'mokyzhang@yeah.net',
        url          = 'http://mokyz.github.io/',
        description  = 'A simple printer of nested lists',
    )
